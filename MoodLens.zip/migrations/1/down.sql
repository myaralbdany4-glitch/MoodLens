
DROP INDEX idx_daily_mood_tracking_user_date;
DROP INDEX idx_user_profiles_user_id;
DROP INDEX idx_mood_sessions_created_at;
DROP INDEX idx_mood_sessions_user_id;
DROP TABLE daily_mood_tracking;
DROP TABLE user_profiles;
DROP TABLE mood_sessions;
